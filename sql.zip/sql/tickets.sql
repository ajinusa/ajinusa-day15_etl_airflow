DROP TABLE IF EXISTS transform.tickets;

CREATE TABLE transform.tickets AS
SELECT 
    "ticketId" AS ticket_id,
    "visitorId" AS visitor_id,
    "price" AS price,
    "status" AS status,
    "purchaseDate" AS purchase_date
FROM assignment.tickets;
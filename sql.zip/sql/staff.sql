DROP TABLE IF EXISTS transform.staff;

CREATE TABLE transform.staff AS
SELECT 
    "staffId" AS staff_id,
    "firstName" AS first_name,
    "lastName" AS last_name,
    "position" AS position,
    "salary" AS salary
FROM assignment.staff;
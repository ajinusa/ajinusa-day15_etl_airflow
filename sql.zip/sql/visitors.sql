DROP TABLE IF EXISTS transform.visitors;

CREATE TABLE transform.visitors AS
SELECT 
    "visitorId" AS visitor_id,
    "firstName" AS first_name,
    "lastName" AS last_name,
    "address" AS address,
    "visitDate" AS visit_date
FROM assignment.visitors;
-- Active: 1734492879395@@127.0.0.1@5434@postgres@assignment
DROP TABLE IF EXISTS transform.animals;

CREATE TABLE transform.animals AS
SELECT 
    "animalId" AS animal_id,
    "name" AS name,
    "species" AS species,
    "age" AS age,
    "diet" AS diet
FROM assignment.animals;

DROP TABLE IF EXISTS transform.enclosures;

CREATE TABLE transform.enclosures AS
SELECT 
    "enclosureId" AS enclosure_id,
    "name" AS name,
    "capacity" AS capacity,
    "animalType" AS animal_type
FROM assignment.enclosures;